/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dcit50_lab2_scoreanalyzer_escogio;

/**
 *
 * @author ICT B2-PC010
 */
public class DCIT50_Lab2_ScoreAnalyzer_escogio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
